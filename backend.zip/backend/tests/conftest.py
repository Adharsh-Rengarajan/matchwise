import pytest
import asyncio
import sys
import os

from httpx import AsyncClient, ASGITransport
from motor.motor_asyncio import AsyncIOMotorClient

# Ensure project root is on PYTHONPATH BEFORE imports
ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, ROOT_DIR)

# Correct imports
from backend.app.main import app
from backend.app.database import get_database

TEST_DB_NAME = "matchwise_test"


@pytest.fixture(scope="session")
def event_loop():
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


@pytest.fixture(scope="session")
async def test_db():
    """Create a separate test database."""
    client = AsyncIOMotorClient("mongodb://localhost:27017")
    db = client[TEST_DB_NAME]

    # Clean DB before tests
    for collection_name in await db.list_collection_names():
        await db.drop_collection(collection_name)

    yield db

    # Clean DB after tests
    for collection_name in await db.list_collection_names():
        await db.drop_collection(collection_name)


@pytest.fixture(scope="function")
async def client(test_db, monkeypatch):
    """Create a test client using ASGITransport and override DB dependency."""

    async def override_db():
        return test_db

    app.dependency_overrides[get_database] = override_db

    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c
