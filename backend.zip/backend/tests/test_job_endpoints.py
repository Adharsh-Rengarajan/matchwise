import pytest
from datetime import date


# -------------------------------------------------------
# TEST: Create Job
# -------------------------------------------------------
@pytest.mark.asyncio
async def test_create_job_success(client, recruiter_id):

    payload = {
        "recruiter_id": recruiter_id,
        "title": "Backend Developer",
        "description": "FastAPI job",
        "salary": "40/hr",
        "location": "Mumbai",
        "type": "Full-Time",
        "start_date": "2024-01-01",
        "end_date": None,
        "skills_required": ["Python", "FastAPI"],
        "status": "OPEN"
    }

    response = await client.post("/jobs/", json=payload)
    body = response.json()

    assert response.status_code == 201
    assert body["success"] is True
    assert body["data"]["title"] == "Backend Developer"
    assert body["data"]["recruiter_id"] == recruiter_id
    assert body["data"]["status"] == "OPEN"


# -------------------------------------------------------
# TEST: Create job fails when recruiter does not exist
# -------------------------------------------------------
@pytest.mark.asyncio
async def test_create_job_invalid_recruiter(client):

    payload = {
        "recruiter_id": "000000000000000000000000",
        "title": "Backend Dev",
        "description": "Should fail",
        "salary": "40/hr",
        "location": "Pune",
        "type": "Full-Time",
        "start_date": "2024-01-01",
        "end_date": None,
        "skills_required": [],
        "status": "OPEN"
    }

    response = await client.post("/jobs/", json=payload)
    assert response.status_code == 404
    assert response.json()["message"] == "Recruiter not found"


# -------------------------------------------------------
# TEST: PATCH job status
# -------------------------------------------------------
@pytest.mark.asyncio
async def test_update_job_status(client, recruiter_id, test_db):

    # First create job
    job = {
        "recruiter_id": recruiter_id,
        "title": "Data Engineer",
        "description": "ETL pipelines",
        "salary": "80k/year",
        "location": "Delhi",
        "type": "Full-Time",
        "start_date": "2024-01-02",
        "end_date": None,
        "skills_required": ["Python"],
        "status": "OPEN"
    }
    resp = await client.post("/jobs/", json=job)
    job_id = resp.json()["data"]["id"]

    # Now update status
    update_payload = {
        "status": "HIRING"
    }

    update_resp = await client.patch(f"/jobs/{job_id}", json=update_payload)
    data = update_resp.json()["data"]

    assert update_resp.status_code == 200
    assert data["status"] == "HIRING"


# -------------------------------------------------------
# TEST: PATCH job fails with invalid status
# -------------------------------------------------------
@pytest.mark.asyncio
async def test_update_job_invalid_status(client, recruiter_id, test_db):

    # Create job
    job = {
        "recruiter_id": recruiter_id,
        "title": "QA Tester",
        "description": "Manual testing",
        "salary": "20/hr",
        "location": "Remote",
        "type": "Contract",
        "start_date": "2024-01-01",
        "end_date": None,
        "skills_required": ["Testing"],
        "status": "OPEN"
    }
    resp = await client.post("/jobs/", json=job)
    job_id = resp.json()["data"]["id"]

    # Invalid status update
    response = await client.patch(f"/jobs/{job_id}", json={"status": "WRONG"})
    assert response.status_code == 422  # validation error


# -------------------------------------------------------
# TEST: Get all jobs by recruiter
# -------------------------------------------------------
@pytest.mark.asyncio
async def test_get_jobs_by_recruiter(client, recruiter_id):

    response = await client.get(f"/jobs/{recruiter_id}")

    assert response.status_code == 200
    assert response.json()["success"] is True
    assert isinstance(response.json()["data"], list)


# -------------------------------------------------------
# TEST: Get single job by ID
# -------------------------------------------------------
@pytest.mark.asyncio
async def test_get_single_job(client, recruiter_id):

    # Create job
    job = {
        "recruiter_id": recruiter_id,
        "title": "ML Engineer",
        "description": "ML job",
        "salary": "100k/year",
        "location": "Hyd",
        "type": "Full-Time",
        "start_date": "2024-01-01",
        "end_date": None,
        "skills_required": ["ML"],
        "status": "OPEN"
    }
    resp = await client.post("/jobs/", json=job)
    job_id = resp.json()["data"]["id"]

    result = await client.get(f"/job/{job_id}")
    assert result.status_code == 200
    assert result.json()["data"]["id"] == job_id
